package com.jdevbook.chap4;

public class Car extends Vehicle 
{
}
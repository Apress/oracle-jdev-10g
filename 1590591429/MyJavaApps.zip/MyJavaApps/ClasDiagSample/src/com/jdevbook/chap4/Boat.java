package com.jdevbook.chap4;

public class Boat extends Vehicle 
{
}
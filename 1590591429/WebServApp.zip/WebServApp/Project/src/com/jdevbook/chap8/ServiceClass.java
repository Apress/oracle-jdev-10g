package com.jdevbook.chap8;
public class ServiceClass 
{
  public String numberSquare(int number)
  {
    return "The square of the number "+ number +" is "+ number * number;
  }  
}
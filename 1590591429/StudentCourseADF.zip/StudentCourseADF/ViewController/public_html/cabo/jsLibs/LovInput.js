var _LovEV="event";
var _LovFL="field";
var _LovFR="form";
var _LovHR;
var _LovLD=0;
var _LovNM=null;
var _LovPT="partialTargets";
var _LovSF=null;
var _LovSR="source";
var _LovST="searchText";
var _LovWN='lovWindow';
function _LovInputVTF(a0,
a1,
a2,
a3,
a4)
{
var a5=(a4!=(void 0));
var a6=new Date();
var a7=null;
if(a5)
{
if(_LovLD)
{
var a8=a6-_LovLD;
if((a8>=0)&&(a8<2000))
{
return false;
}
}
_LovLD=a6;
}
var a9=false;
var a10=true;
if(a2)
{
if(a2.value)
{
a10=(a2.value.search(/\S/)<0);
}
if(a10)
{
if((a3!=(void 0))&&a3)
{
a9=!a5;
}
}
else
{
a9=!a5;
}
if(a9)
{
if(a0)
{
var a11=new Object();
var a12=0;
var a13=new Object();
if(a2.form!=(void 0))
{
a7=a2.form;
if(a7.action!=(void 0))
a12=a7.action;
}
a12=_LovInputDDP(a12,a11);
for(var a14 in a11)
a13[a14]=a11[a14];
if(a2.id)
a11[_LovSR]=a2.id;
else
a11[_LovSR]=a2.name;
a11[_LovST]=a2.value;
a11[_LovPT]=a0;
if(_LovInputMPC(a1,a11,'lovValidate',false))
{
var a15=_LovInputUSF();
for(a14 in a11)
{
if((a13[a14]!=null)
&&(a13[a14]==a11[a14]))
{
delete a11[a14];
}
else
{
if(a13[a14]!=null)
{
delete a13[a14];
}
if(!a15)
a11[a14]=_LovInputENC(a11[a14]);
}
}
var a16=false;
if(a15)
{
var a17=_LovInputUAA(a12,a13,a16);
a11[_getPartialParameter()]=true;
_LovInputSFS(a11,a7,a17);
}
else
{
for(a14 in a13)
a11[a14]=a13[a14];
a12=_LovInputUAA(a12,a11,a16);
_firePartialChange(a12);
}
}
}
}
if(a5)
_LovInputOLW(a0,a4);
else
_navDirty=true;
}
return(a10&&!a5);
}
function _LovInputOLW(a0,a1)
{
var a2=_getDependent(window,_LovWN);
var a3=a1;
if(a3==(void 0))
{
a3=new Object();
}
var a4=_LovInputGPF(a3,'A',false);
var a5=_LovInputGPF(a3,'F',0);
var a6=_LovInputGPF(a3,'N',0);
if(!((a4||a6)&&a5))
return;
var a7=_LovInputGPF(a3,'L',0);
var a8=_LovInputGPF(a3,'T',a6);
var a9=_LovInputGPF(a3,'I',0);
var a10=_LovInputGPF(a3,'S',0);
var a11=_LovEV;
var a12=_LovInputGPF(a3,'D',location.href);
var a13;
if(!a4)
{
var a14=document[a5][a8];
if(!a14)
return;
a13=a14.value;
}
else
a13=_LovInputGPF(a3,'R','');
_LovSF=a10;
_LovNM=new Object();
_LovNM[_LovFR]=a5;
_LovNM[_LovFL]=a8;
if(a7)
_LovNM[_LovSR]=a7;
else
_LovNM[_LovSR]=a6;
_LovNM[_LovPT]=a0;
if(a2!=(void 0))
{
return false;
}
var a15=new Object();
a12=_LovInputDDP(a12,a15);
a15[_LovSR]=_LovNM[_LovSR];
a15[_LovST]=a13;
if(!_LovInputMPC(a9,a15,"lovFilter",true))
return false;
a12=_LovInputUAA(a12,a15,true);
_LovHR=location.href;
_LovInputOMW(a12,_LovInputWCB);
return false;
}
function _LovInputGPF(a0,a1,a2)
{
var a3;
if(a0!=(void 0))
{
a3=a0[a1];
}
if(a3==(void 0))
a3=a2;
return a3;
}
function _LovInputMPC(a0,a1,a2,a3)
{
var a4=_LovEV;
var a5=null;
if(a3)
a5=a1[a4];
delete a1[a4];
if(a0)
{
var a6=a0(a1);
if(!a6)
return false;
}
if(!a1[a4])
{
if(a5)
{
a1[a4]=a5;
}
else
{
a1[a4]=a2;
}
}
return true;
}
function _LovInputOMW(a0,a1)
{
var a2=location.protocol+'//'+location.host;
a2+=_jspDir+'?_t=';
if(_LovInputUSF())
{
a2+='fredRC&';
if(_enc)
a2+="enc="+_enc+"&";
}
else
a2+='fred&';
a2+='_minWidth=750&_minHeight=550&';
if(_configName)
a2+="configName="+_configName+"&";
if(_contextURI)
a2+="contextURI="+_contextURI+"&";
a2+='redirect=';
if(a0.charAt(0)!='/')
{
var a3=location.pathname;
a0=(a3.substr(0,a3.lastIndexOf('/')+1)
+a0);
}
a2+=a0.replace('?','&');
lovw=openWindow(window,a2,_LovWN,{width:750,height:550},
true,'dialog',a1);
lovw._LovSL=false;
lovw._LovSF=_LovSF;
lovw._LovNM=_LovNM;
}
function _LovInputPWP(a0,a1)
{
var a2=window[a0];
if(a2==(void 0))
{
if(a1[a0])
{
a2=a1[a0];
}
else if(top[a0])
{
a2=top[a0];
}
else if(a1.opener[a0])
{
a2=a1.opener[a0];
}
}
return a2;
}
function _LovInputWCB(a0,a1)
{
var a2=true;
if(!a0._LovSL)
return false;
_LovNM=_LovInputPWP('_LovNM',a0);
if(_LovNM==null)
return false;
a0.opener._navDirty=true;
if(a2)
{
var a3=new Object();
a3[_LovEV]='lovUpdate';
a3[_LovSR]=_LovNM[_LovSR];
var a4=_LovNM[_LovPT];
if(a4)
{
a3[_LovPT]=a4;
}
var a5=_LovInputPWP('_lovClose',a0);
var a6=_LovNM[_LovFR];
if((a5!=(void 0))&&(a6!=(void 0)))
{
a5(a6,a3,(a4));
}
else
{
var a7=_LovInputDDP(0,a3);
if(a4)
{
a7=_LovInputUAA(a7,a3,true);
_firePartialChange(a7);
}
else
{
a7=_LovInputUAA(a7,a3,true);
location=a7;
}
}
}
return false;
}
function _LovInputDDP(a0,a1)
{
var a2=a0;
if(!a0)
{
if(_LovHR!=(void 0))
{
a2=_LovHR;
}
else if((location!=(void 0))
&&(location.href!=(void 0)))
{
a2=location.href;
}
else
{
return"#";
}
}
if(a2.charAt(a2.length-1)=='#')
{
a2=a2.substr(0,a2.length-1);
}
var a3=a2;
var a4=a2.indexOf('?');
if(a4>0)
{
a3=a2.substr(0,a4);
var a5=a2.substr(a4+1);
var a6=a5.split('&');
for(var a7=0;a7<a6.length;a7++)
{
var a8=a6[a7].indexOf('=');
if(a8>=0)
{
a1[a6[a7].substr(0,a8)]=a6[a7].substr(a8+1);
}
else
{
a1[a6[a7]]="";
}
}
}
return a3;
}
function _LovInputUAA(a0,a1,a2)
{
var a3='?';
var a4=a0;
if(a4)
{
for(var a5 in a1)
{
var a6=a1[a5];
a4+=(a3
+(a2?_LovInputENC(a5):a5)
+'=');
if(a6)
a4+=(a2?_LovInputENC(a6):a6);
a3='&';
}
}
return a4;
}
function _LovInputCBF()
{
top.close();
return false;
}
function _LovInputSBF(a0)
{
top._LovSL=true;
var a1=_LovInputPWP('_LovNM',top);
var a2=top.opener;
a2._navDirty=true;
var a3=_LovInputPWP('_LovSF',top);
if(a3)
{
top._LovSL=a3(window,
a2.document[a1[_LovFR]][a1[_LovFL]],
a0,a2);
}
window.onunload=function(){top.close();};
if(_agent.isNav&&_agent.isSolaris)
{
window.onunload=function(){_LovInputWCB(top,a0);};
}
submitForm(0,0,{'event':'lovSelect','source':_LovLI});
}
function _LovInputENC(a0)
{
var a1;
var a2=_agent.isNav||_agent.isMac||_agent.atMost("ie",5.49);
if(!a2)
{
a1=encodeURIComponent(a0);
}
else
{
var a3=escape(a0);
var a4=0;
var a5;
a1="";
while((a5=a3.indexOf('+',a4))>0)
{
a1+=a3.substring(a4,a5)+'%2B';
a4=a5+1;
}
a1+=a3.substring(a4);
}
return a1;
}
function _LovInputQSF(a0,a1)
{
var a2=new TableProxy(a0);
a2.setSelectedRow(a1);
_LovInputSBF();
}
function _LovInputUSF()
{
return _enc.toUpperCase()!="UTF-8";
}
function _LovInputSFS(a0,a1,a2)
{
var a3=window.document;
var a4="_LovInput";
if(a1.id)
a4+=a1.id;
else if(a1.name)
a4+=a1.name;
else
a4+="DummyForm";
var a5=a3.createElement("form");
a5.id=a4;
a5.name=a4;
a5.target=a1.target;
a5.method=a1.method;
if(a2)
a5.action=a2;
else
a5.action=a1.action;
for(var a6 in a0)
{
var a7=a3.createElement("input");
a7.type="hidden";
a7.name=a6;
a7.value=a0[a6];
a5.appendChild(a7);
}
a3.body.appendChild(a5);
var a8="_"+a5.name+"Validater";
var a9=false;
if(window[a8]==(void 0))
{
a9=true;
window[a8]=1;
}
_submitPartialChange(a5,0,a0);
if(a9&&(!_agent.isIE))
delete window[a8];
a3.body.removeChild(a5);
}
